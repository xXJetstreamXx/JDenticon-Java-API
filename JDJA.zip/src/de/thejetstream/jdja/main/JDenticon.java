package de.thejetstream.jdja.main;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

//Jdenticon Java API
//
//Copyright (c) 2016 - TheJetstream (thejetstream.de)
//- http://stackoverflow.com/users/5118384/jetstream
//- https://github.com/xXJetstreamXx/
//
//License:
//
//		Permission is hereby granted, free of charge, to any person obtaining a copy
//		of this software and associated documentation files (the "Software"), to deal
//		in the Software without restriction, including without limitation the rights
//		to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//		copies of the Software, and to permit persons to whom the Software is
//		furnished to do so, subject to the following conditions:
//
//		The above copyright notice and this permission notice shall be included in all
//		copies or substantial portions of the Software.
//
//		THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//		IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//		FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//		AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//		LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//		OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//		SOFTWARE.
//
//Code from:
//- TheJetstream (http://stackoverflow.com/users/5118384/jetstream)
//- amn (http://stackoverflow.com/users/254343/amn)
//
//JDenticon: jdenticon.com

public class JDenticon {
	
	private String finalHash;
	private String finalSVGString;
	
	/**
	 * Initializes JDenticon without parameters
	 */
	public JDenticon() {
		this.finalHash = null;
	}
	
	/**
	 * Initializes JDenticon with a given <b>hash</b>
	 * @param hash The hash as String
	 */
	public JDenticon(String hash) {
		this.finalHash = hash;
	}
	
	/**
	 * 
	 * @return The current <b>hash</b>
	 */
	public String getHash() {
		return finalHash;
	}
	
	/**
	 * Sets the current <b>hash</b> to a specific String
	 * @param newHash The new hash as String
	 */
	public void setHash(String newHash) {
		this.finalHash = newHash;
	}
	
	/**
	 * Sets the curren <b>SVGString</b> to a specific String
	 * @param newSVGString the new <b>SVGString</b>
	 */
	public void setSVGString(String newSVGString) {
		this.finalSVGString = newSVGString;
	}
	
	/**
	 * 
	 * @return The current <b>SVGString</b>
	 */
	public String getSVGString() {
		return this.finalSVGString;
	}
	
	/**
	 * Saves a <b>.svg</b> to a specific path on your computer.
	 * @param svgString The .svg file as String
	 * @param filename the name of the file
	 * @param location The location where it should be saved (e.g. "C:/")
	 * @return <b>true</b> if everything worked, <b>false</b> if not
	 * @throws IOException
	 */
	public boolean saveSVG(String svgString, String filename, String location) throws IOException {
		try {
			byte[] b = svgString.getBytes();
	    	FileOutputStream out = new FileOutputStream(location + filename + ".svg");
	    	out.write(b);
	    	out.close();
	    	return true;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	/**
	 * Saves a <b>.svg</b> to a specific path on your computer. Uses the
	 * current saved <b>SVGString</b> (setSVGString()-method)
	 * @param filename the name of the file
	 * @param location The location where it should be saved (e.g. "C:/")
	 * @return <b>true</b> if everything worked, <b>false</b> if not
	 * @throws IOException
	 */
	public boolean saveSVG(String filename, String location) {
		if (finalSVGString != null) {
			try {
				byte[] b = finalSVGString.getBytes();
		    	FileOutputStream out = new FileOutputStream(location + filename + ".svg");
		    	out.write(b);
		    	out.close();
		    	return true;
			} catch (IOException e) {
				e.printStackTrace();
				return false;
			}
		} else {
			return false;
		}
	}
	
	/**
	 * Returns a <b>SVGString</b>. This has to be saved in an .svg file <br>
	 * in order to be viewed through Browser (e.g. Firefox) <br>
	 * The current <b>ash</b> is used (see setHash()-method)
	 * @param size The <b>size</b> of the generated SVG (only 1:1 size is possible)
	 * @return The String containing the content of the .svg file.
	 * @throws ScriptException
	 * @throws FileNotFoundException
	 */
	public String generateSVG(int size) throws FileNotFoundException, ScriptException {
		if (finalHash != null) {
			ScriptEngineManager factory = new ScriptEngineManager();
	        ScriptEngine scriptEngine = factory.getEngineByName("JavaScript");
	        scriptEngine.eval(new FileReader("src/jdenticon.js"));
	        return scriptEngine.eval("jdenticon.toSvg(\"" + finalHash + "\", \"" + size + "\")").toString();
		} else {
			return null;
		}
	}
	
	/**
	 * Returns a <b>SVGString</b>. This has to be saved in an .svg file <br>
	 * in order to be viewed through Browser (e.g. Firefox)
	 * @param hash The <b>hash</b> as string used to generate the .svg
	 * @param size The <b>size</b> of the generated SVG (only 1:1 size is possible)
	 * @return The String containing the content of the .svg file.
	 * @throws ScriptException
	 * @throws FileNotFoundException
	 */
	public String generateSVG(String hash, int size) throws FileNotFoundException, ScriptException {
		ScriptEngineManager factory = new ScriptEngineManager();
        ScriptEngine scriptEngine = factory.getEngineByName("JavaScript");       
        scriptEngine.eval(new FileReader("src/jdenticon.js"));
        return scriptEngine.eval("jdenticon.toSvg(\"" + hash + "\", \"" + size + "\")").toString();
	}
	
	/**
	 * Generates a <b>hash</b> from a given string.
	 * @param toHash The string that should be transformed into a hash.
	 * @return
	 */
	public String generateHash(String toHash) {
		try {
        	MessageDigest md = MessageDigest.getInstance("MD5");
        	return hex (md.digest(toHash.getBytes("CP1252")));
        } catch (NoSuchAlgorithmException e) {
        } catch (UnsupportedEncodingException e) {}
        return null;
	}
	
	private String hex(byte[] array) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < array.length; ++i) {
        	sb.append(Integer.toHexString((array[i] & 0xFF) | 0x100).substring(1,3));        
        }
        return sb.toString();
    }

}
